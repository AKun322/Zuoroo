# 参考资料

1. 王珊, 萨师煊. 数据库系统概论(第5版). 北京: 高等教育出版社, 2014
2. Hector Garcia-Mlina, Jeffrey D. Ullman, Jennifer Widom. 杨冬青 等译. 数据库系统实现. 北京: 机械工业出版社, 2010
3. Abraham Silberschatz, Henry F.Korth, S. Sudarshan. 杨冬青 等译. 数据库系统概念(第6版). 北京: 机械工业出版社, 2012
4. 李海翔. 数据库查询优化器的艺术原理解析与SQL性能优化. 北京: 机械工业出版社, 2014
5. [CMU 15445](https://15445.courses.cs.cmu.edu/fall2020/schedule.html)

